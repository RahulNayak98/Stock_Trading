package com.thrive.client.cache;

public enum CacheName {
    USER;
}
