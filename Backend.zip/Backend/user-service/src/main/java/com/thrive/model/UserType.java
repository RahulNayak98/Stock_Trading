package com.thrive.model;

public enum UserType {
    EXTERNAL_USER,
    ADMIN;
}
