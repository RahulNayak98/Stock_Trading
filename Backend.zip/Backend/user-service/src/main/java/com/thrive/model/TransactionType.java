package com.thrive.model;

public enum TransactionType {
    BUY,
    SELL,
    DEPOSIT,
    WITHDRAW;
}
